package com.example.klighty.lib2;

public class MyClass {
}
