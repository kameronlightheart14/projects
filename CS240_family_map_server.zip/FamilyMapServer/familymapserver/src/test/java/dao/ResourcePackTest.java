package dao;

import org.junit.Test;

import static org.junit.Assert.*;

public class ResourcePackTest {

    @Test
    public void testJsonReader() {
        String test = ResourcePack.fnames.get(0);
//        System.out.println(ResourcePack.getRandomLocation().toString());
//        System.out.println(ResourcePack.getRandomFemaleName());
//        System.out.println(ResourcePack.getRandomMaleName());
//        System.out.println(ResourcePack.getRandomLastName());
    }

}